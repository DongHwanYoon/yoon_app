package kr.ac.sunmoon.model.dto;

public class PortfolioData {
	private int no;
	private int portfolioNo;
	private String originalFileName;
	private String realFileName;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getPortfolioNo() {
		return portfolioNo;
	}

	public void setPortfolioNo(int portfolioNo) {
		this.portfolioNo = portfolioNo;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getRealFileName() {
		return realFileName;
	}

	public void setRealFileName(String realFileName) {
		this.realFileName = realFileName;
	}
	
	

	public PortfolioData(String originalFileName, String realFileName) {
		super();
		this.originalFileName = originalFileName;
		this.realFileName = realFileName;
	}

	public PortfolioData(int portfolioNo, String originalFileName, String realFileName) {
		super();
		this.portfolioNo = portfolioNo;
		this.originalFileName = originalFileName;
		this.realFileName = realFileName;
	}

	public PortfolioData(int no, int portfolioNo, String originalFileName, String realFileName) {
		super();
		this.no = no;
		this.portfolioNo = portfolioNo;
		this.originalFileName = originalFileName;
		this.realFileName = realFileName;
	}

}
